Free Download Source Code "Advance Student Enrollment System Project"

FIRST Download

1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.

3"voting management system"

4. Download the zip file/ download winrar

5. Extract the file and copy "student-php-enrollment" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name student

6. Import student.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/student-php-enrollment

Username: test12345
Password: 123456789
