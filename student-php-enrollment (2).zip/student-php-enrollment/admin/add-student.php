
<b style="color:transparent;" hidden="">
<?php 
  $corepage = explode('/', $_SERVER['PHP_SELF']);
    $corepage = end($corepage);
    if ($corepage!=='index.php') {
      if ($corepage==$corepage) {
        $corepage = explode('.', $corepage);
       header('Location: index.php?page='.$corepage[0]);
     }
    }

  if (isset($_POST['addstudent'])) {
  	$name = $_POST['name'];
  	$roll = $_POST['roll'];
  	$semester = $_POST['semester'];
  	$course = $_POST['course'];
  	$address = $_POST['address'];
  	$pcontact = $_POST['pcontact'];
  	$class = $_POST['class'];
  	$photo = explode('.', $_FILES['photo']['name']);
  	$photo = end($photo); 
  	$photo = $roll.date('Y-m-d-m-s').'.'.$photo;

  	$query = "INSERT INTO `student_info`(`name`, `roll`, `class`, `city`, `pcontact`, `photo`, `Course`, `semester`) VALUES ('$name', '$roll', '$class', '$address', '$pcontact','$photo','$course','$semester');";
  	if (mysqli_query($db_con,$query)) {
  		$datainsert['insertsucess'] = '<p style="color: green;">Student Added!</p>';
  		move_uploaded_file($_FILES['photo']['tmp_name'], 'images/'.$photo);
  		header('Refresh:3; index.php?page=all-student', true, 303);//header( "Refresh:5; index.php", true, 303); 
  	}else{
  		$datainsert['inserterror']= '<p style="color: red;">Student Not Added, please input right informations!</p>';
  	}
  }
  $query= "SELECT * from student_info order by id desc limit 1";
  $result= mysqli_query($db_con,$query);
  $row= mysqli_fetch_array($result);
  $lastid=$row['id'];
  if($lastid== " ")
  {
  		$empid="Emp1";
  }
  else
  {
  	$empid= substr($lastid,3);
  	$empid= intval($empid);
  	$empid=	date('Y').($lastid +1);
  }
?></b>
<h1 class="text-primary"><i class="fas fa-user-plus"></i>  Add Student<small class="text-warning"> Add New Student!</small></h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
     <li class="breadcrumb-item" aria-current="page"><a href="index.php">Dashboard </a></li>
     <li class="breadcrumb-item active" aria-current="page">Add Student</li>
  </ol>
</nav>

<div class="row">
	
<div class="col-sm-6">
		<?php if (isset($datainsert)) {?>
	<div role="alert" aria-live="assertive" aria-atomic="true" class="toast fade" data-autohide="true" data-animation="true" data-delay="2000">
	  <div class="toast-header">
	    <strong class="mr-auto">Student Insert Alert</strong>
	    <small><?php echo date('d-M-Y'); ?></small>
	    <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
	      <span aria-hidden="true">&times;</span>
	    </button>
	  </div>
	  <div class="toast-body">
	    <?php 
	    	if (isset($datainsert['insertsucess'])) {
	    		echo $datainsert['insertsucess'];
	    	}
	    	if (isset($datainsert['inserterror'])) {
	    		echo $datainsert['inserterror'];
	    	}
	    ?>
	  </div>
	</div>
		<?php } ?>
	<form enctype="multipart/form-data" method="POST" action="">
		<div class="form-group">
		    <label for="roll">ID</label>
		    <input name="roll" type="text" class="form-control" id="pcontact"  value="<?php echo $empid;?>" placeholder="" readonly>
	  	</div>
		<div class="form-group">
		    <label for="name">Student Name</label>
		    <input name="name" type="text" class="form-control" id="name" value="<?= isset($name)? $name: '' ; ?>" required="">
	  	</div>
	  	<!--<div class="form-group">
		    <label for="">Student ID Number</label>
		    <input name="" type="text" value="<?= isset($roll)? $roll: '' ; ?>" class="form-control" pattern="[0-9]{10}" id="roll" >
	  	</div>-->
	  	<div class="form-group">
		    <label for="address">Student Address</label>
		    <input name="address" type="text" value="<?= isset($address)? $address: '' ; ?>" class="form-control" id="address" required="">
	  	</div>
	  	<div class="form-group">
		    <label for="pcontact">Parent Contact NO</label>
		    <input name="pcontact" type="text" class="form-control" id="pcontact" pattern="[0-9]{11}" value="<?= isset($pcontact)? $pcontact: '' ; ?>" placeholder="09xxx-xxx-xxx" required="">
	  	</div>
	  	<div class="form-group">
		    <label for="course">Course</label>
		    <input name="course" type="text" class="form-control" id="pcontact" value="<?= isset($course)? $course: '' ; ?>" placeholder="" required="">
	  	</div>
	  	<div class="form-group">
		    <label for="class">Year</label>
		    <select name="class" class="form-control" id="class" required="">
		    	<option>Select</option>
		    	<option value="1st">1st</option>
		    	<option value="2nd">2nd</option>
		    	<option value="3rd">3rd</option>
		    	<option value="4th">4th</option>
		    </select>

	  	</div>
	  	 	<div class="form-group">
		    <label for="semester">Semester</label>
		    <select name="semester" class="form-control" id="class" required="">
		    	<option>Select</option>
		    	<option value="1st">1st</option>
		    	<option value="2nd">2nd</option>
		    </select>
	  	</div>
	  	<div class="form-group">
		    <label for="photo">Student Photo</label>
		    <input name="photo" type="file" class="form-control" id="photo" required="">
	  	</div>
	  	<div class="form-group text-center">
		    <input name="addstudent" value="Add Student" type="submit" class="btn btn-danger">
	  	</div>
	 </form>
</div>
</div>