 <b hidden="">
<?php 
// $corepage = explode('/', $_SERVER['PHP_SELF']);
   // $corepage = end($corepage);
   // if ($corepage!=='index.php') {
   //   if ($corepage==$corepage) {
   //     $corepage = explode('.', $corepage);
    //   header('Location: index.php?page='.$corepage[0]);
  //  }
    //}

 require_once 'admin/db_con.php'; 

  if (isset($_POST['addstudent'])) {
  	$name = $_POST['name'];
  	$roll = $_POST['roll'];	
  	$semester = $_POST['semester'];
  	$address = $_POST['address'];
  	$pcontact = $_POST['pcontact'];
  	$class = $_POST['class'];
  	$course= $_POST['course'];
  	$photo = explode('.', $_FILES['photo']['name']);
  	$photo = end($photo); 
  	$photo = $roll.date('Y-m-d-m-s').'.'.$photo;

  	$query = "INSERT INTO `student_info`(`name`, `roll`, `class`, `city`, `pcontact`, `photo`, `Course`, `semester`) VALUES ('$name', '$roll', '$class', '$address', '$pcontact','$photo','$course','$semester');";
  	if (mysqli_query($db_con,$query)) {
  		$datainsert['insertsucess'] = '<p style="color: green;">You\'re now Enrolled!</p>';
  		move_uploaded_file($_FILES['photo']['tmp_name'], 'admin/images/'.$photo);
  		header('Refresh:5; index.php', true, 303);//header( "Refresh:5; index.php", true, 303); 
  	}else{
  		$datainsert['inserterror']= '<p style="color: red;">Student Not Added, please input right informations!</p>';
  	}
  }
  $query= "SELECT * from student_info order by id desc limit 1";
  $result= mysqli_query($db_con,$query);
  $row= mysqli_fetch_array($result);
  $lastid=$row['id'];
  if($lastid== " ")
  {
  		$empid="Emp1";
  }
  else
  {
  	$empid= substr($lastid,3);
  	$empid= intval($empid);
  	$empid=	date('Y').($lastid +1);
  }
?>
<?php require_once 'admin/db_con.php'; ?>
</b>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="css/fontawesome.min.css">
    <link rel="stylesheet" href="css/solid.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css"/>
    <link rel="stylesheet" type="text/css" href="../css/style.css">

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap4.min.js"></script>
    <script src="js/fontawesome.min.js"></script>
    <script src="js/script.js"></script>
    <title>This page</title>
    <style type="text/css">
    	label{
    		font-size: bold;
    		color:white;
    	}
    	    </style>
  </head>
  <body style="background-color: darkblue;background-image: url(logo.png);background-size:30%;background-repeat: no-repeat;  background-repeat: no-repeat;
  background-attachment: fixed;background-position: center">

<div class="container col-sm-6">
<h1 class="" style="color:white;text-align: center"><i class="fas fa-user-plus" style="color:white"></i> Enrollment Form<small class="text-warning"></small></h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb" style="background-color: yellow;color:white;">
     <li class="breadcrumb-item active" aria-current="page">Enrollment</li>
  </ol>
</nav>

<div class="row">
	
<div class="col-sm-12">
		<?php if(isset($datainsert)) {?>
	<div role="alert" aria-live="assertive" aria-atomic="true" class="toast fade" data-autohide="true" data-animation="true" data-delay="2000">
	  <div class="toast-header">
	    <strong class="mr-auto">Student Insert Alert</strong>
	    <small><?php echo date('d-M-Y'); ?></small>
	    <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
	      <span aria-hidden="true">&times;</span>
	    </button>
	  </div>
	  <div class="toast-body">
	    <?php 
	    	if (isset($datainsert['insertsucess'])) {
	    		echo $datainsert['insertsucess'];
	    	}
	    	if (isset($datainsert['inserterror'])) {
	    		echo $datainsert['inserterror'];
	    	}
	    ?>
	  </div>
	</div>
		<?php } ?>
	<form enctype="multipart/form-data" method="POST" action="">
		<div class="form-group">
		    <label for="roll">ID</label>
		    <input name="roll" type="text" class="form-control" id="pcontact"  value="<?php echo $empid;?>" placeholder="" readonly>
	  	</div>
		<div class="form-group">
		    <label for="name">Student Name</label>
		    <input name="name" type="text" class="form-control" id="name" value="<?= isset($name)? $name: '' ; ?>" required="">
	  	</div>
	  	<!--<div class="form-group">
		    <label for="">Student ID Number</label>
		    <input name="" type="text" value="<?= isset($roll)? $roll: '' ; ?>" class="form-control" pattern="[0-9]{10}" id="roll" >
	  	</div>-->
	  	<div class="form-group">
		    <label for="address">Student Address</label>
		    <input name="address" type="text" value="<?= isset($address)? $address: '' ; ?>" class="form-control" id="address" required="">
	  	</div>
	  	<div class="form-group">
		    <label for="pcontact">Parent Contact NO</label>
		    <input name="pcontact" type="text" class="form-control" id="pcontact" pattern="[0-9]{11}" value="<?= isset($pcontact)? $pcontact: '' ; ?>" placeholder="09----" required="">
	  	</div>
	  	<div class="form-group">
		    <label for="pcontact">Course</label>
		    <input name="course" type="text" class="form-control" id="pcontact" value="<?= isset($course)? $course: '' ; ?>" placeholder="" required="">
	  	</div>
	  	<div class="form-group">
		    <label for="class">Year</label>
		    <select name="class" class="form-control" id="class" required="">
		    	<option>Select</option>
		    	<option value="1st">1st</option>
		    	<option value="2nd">2nd</option>
		    	<option value="3rd">3rd</option>
		    	<option value="4th">4th</option>
		    </select>

	  	</div>
	  	 	<div class="form-group">
		    <label for="class">Semester</label>
		    <select name="semester" class="form-control" id="class" required="">
		    	<option>Select</option>
		    	<option value="1st">1st</option>
		    	<option value="2nd">2nd</option>
		    </select>
	  	</div>
	  	<div class="form-group">
		    <label for="photo">Student Photo</label>
		    <input name="photo" type="file" class="form-control" id="photo" required="">
	  	</div>
	  	<div class="form-group text-center">
	  		<a href="index.php" class="btn btn-success">Cancel</a>
		    <input name="addstudent" value="Enroll" type="submit" class="btn btn-success">
	  	</div>
	 </form>
</div>
</div>
</div>
    <script type="text/javascript">
      jQuery('.toast').toast('show');
    </script>
</body>
</html>